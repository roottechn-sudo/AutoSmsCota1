package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "cotisations",
    foreignKeys = [
        ForeignKey(
            entity = EventCampaignEntity::class,
            parentColumns = ["idCampagne"],
            childColumns = ["idCampagne"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("idCampagne"),
        Index("membreUid")
    ]
)
data class CotisationEntity(
    @PrimaryKey
    val idTransaction: String,
    val idCampagne: String,
    val membreUid: String, // UID du membre ou "ANONYMOUS" ou "SYMPATHISANT"
    val montant: Double,
    val datePaiement: Long = System.currentTimeMillis(),
    val methodePaiement: String, // "ORANGE_MONEY", "MOOV_MONEY", "WAVE", "STRIPE", "PAYPAL", "LIGDICASH", "ESPECE"
    val enregistreParUid: String,
    val recuGenere: Boolean = true,
    val syncedToFirebase: Boolean = false,
    val referenceExterne: String? = null,
    val isAnonyme: Boolean = false,
    val donateurNom: String? = null, // Nom de l'ami, du bienfaiteur ou du sympathisant non-membre
    val donateurTelephone: String? = null,
    val typeContributeur: String = "MEMBRE" // "MEMBRE", "SYMPATHISANT", "ANONYME"
) {
    fun getDisplayName(memberName: String?): String {
        return when (typeContributeur) {
            "ANONYME" -> "Donateur Anonyme"
            "SYMPATHISANT" -> donateurNom?.ifBlank { null } ?: "Ami & Sympathisant RAVA"
            else -> memberName ?: donateurNom ?: "Membre N° $membreUid"
        }
    }
}
